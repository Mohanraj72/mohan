import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { FirstpageComponent } from './components/firstpage/firstpage.component';
import { SignupComponent } from './components/signup/signup.component';
import { MentorregComponent } from './components/mentorreg/mentorreg.component';
import { MenhomeComponent } from './components/menhome/menhome.component';
import { NavmenComponent } from './components/navmen/navmen.component';
import { MenfirstComponent } from './components/menfirst/menfirst.component';
import { MennotifyComponent } from './components/mennotify/mennotify.component';
import { MenpayComponent } from './components/menpay/menpay.component';
import { NavuserComponent } from './components/navuser/navuser.component';
import { UserhomeComponent } from './components/userhome/userhome.component';
import { UserpropComponent } from './components/userprop/userprop.component';
import { UserfirstComponent } from './components/userfirst/userfirst.component';
import { UsersearchComponent } from './components/usersearch/usersearch.component';
import { NavadComponent } from './components/navad/navad.component';
import { AdhomeComponent } from './components/adhome/adhome.component';
import { AdpaymadeComponent } from './components/adpaymade/adpaymade.component';
import { AdfirstComponent } from './components/adfirst/adfirst.component';
import { AdpayComponent } from './components/adpay/adpay.component';
import { AdtechComponent } from './components/adtech/adtech.component';
import { TokenInterceptor } from './components/core/interceptor';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { ApiService } from './components/service/api.service';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    LoginComponent,
    HomeComponent,
    FirstpageComponent,
    SignupComponent,
    MentorregComponent,
    MenhomeComponent,
    NavmenComponent,
    MenfirstComponent,
    MennotifyComponent,
    MenpayComponent,
    NavuserComponent,
    UserhomeComponent,
    UserpropComponent,
    UserfirstComponent,
    UsersearchComponent,
    NavadComponent,
    AdhomeComponent,
    AdpaymadeComponent,
    AdfirstComponent,
    AdpayComponent,
    AdtechComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [
    ApiService,{provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
      }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
