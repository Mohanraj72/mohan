import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserpropComponent } from './userprop.component';

describe('UserpropComponent', () => {
  let component: UserpropComponent;
  let fixture: ComponentFixture<UserpropComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserpropComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserpropComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
