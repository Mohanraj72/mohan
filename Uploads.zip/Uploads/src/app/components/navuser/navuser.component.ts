import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'navuser',
  templateUrl: './navuser.component.html',
  styleUrls: ['./navuser.component.css']
})
export class NavuserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
