import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'adtech',
  templateUrl: './adtech.component.html',
  styleUrls: ['./adtech.component.css']
})
export class AdtechComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
