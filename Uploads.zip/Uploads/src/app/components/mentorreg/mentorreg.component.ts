import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mentorreg',
  templateUrl: './mentorreg.component.html',
  styleUrls: ['./mentorreg.component.css']
})
export class MentorregComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
