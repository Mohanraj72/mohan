import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'adpaymade',
  templateUrl: './adpaymade.component.html',
  styleUrls: ['./adpaymade.component.css']
})
export class AdpaymadeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
