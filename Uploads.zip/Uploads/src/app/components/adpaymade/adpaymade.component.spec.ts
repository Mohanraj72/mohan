import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdpaymadeComponent } from './adpaymade.component';

describe('AdpaymadeComponent', () => {
  let component: AdpaymadeComponent;
  let fixture: ComponentFixture<AdpaymadeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdpaymadeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdpaymadeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
