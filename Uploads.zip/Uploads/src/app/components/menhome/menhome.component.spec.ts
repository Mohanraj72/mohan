import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenhomeComponent } from './menhome.component';

describe('MenhomeComponent', () => {
  let component: MenhomeComponent;
  let fixture: ComponentFixture<MenhomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenhomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenhomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
