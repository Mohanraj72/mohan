import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdfirstComponent } from './adfirst.component';

describe('AdfirstComponent', () => {
  let component: AdfirstComponent;
  let fixture: ComponentFixture<AdfirstComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdfirstComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdfirstComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
