import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adfirst',
  templateUrl: './adfirst.component.html',
  styleUrls: ['./adfirst.component.css']
})
export class AdfirstComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
