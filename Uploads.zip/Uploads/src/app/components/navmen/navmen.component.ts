import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'navmen',
  templateUrl: './navmen.component.html',
  styleUrls: ['./navmen.component.css']
})
export class NavmenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
