import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NavmenComponent } from './navmen.component';

describe('NavmenComponent', () => {
  let component: NavmenComponent;
  let fixture: ComponentFixture<NavmenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NavmenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavmenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
