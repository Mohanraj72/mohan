import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mennotify',
  templateUrl: './mennotify.component.html',
  styleUrls: ['./mennotify.component.css']
})
export class MennotifyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
