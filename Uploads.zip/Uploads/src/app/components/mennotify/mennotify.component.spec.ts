import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MennotifyComponent } from './mennotify.component';

describe('MennotifyComponent', () => {
  let component: MennotifyComponent;
  let fixture: ComponentFixture<MennotifyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MennotifyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MennotifyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
