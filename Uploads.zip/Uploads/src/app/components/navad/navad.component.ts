import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'navad',
  templateUrl: './navad.component.html',
  styleUrls: ['./navad.component.css']
})
export class NavadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
