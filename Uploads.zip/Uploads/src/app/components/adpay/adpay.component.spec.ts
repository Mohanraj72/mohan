import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdpayComponent } from './adpay.component';

describe('AdpayComponent', () => {
  let component: AdpayComponent;
  let fixture: ComponentFixture<AdpayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdpayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdpayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
