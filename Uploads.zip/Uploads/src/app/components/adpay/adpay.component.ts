import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'adpay',
  templateUrl: './adpay.component.html',
  styleUrls: ['./adpay.component.css']
})
export class AdpayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
