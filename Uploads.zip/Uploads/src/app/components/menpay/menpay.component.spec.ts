import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenpayComponent } from './menpay.component';

describe('MenpayComponent', () => {
  let component: MenpayComponent;
  let fixture: ComponentFixture<MenpayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenpayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenpayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
