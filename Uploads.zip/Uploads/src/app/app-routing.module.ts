import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { FirstpageComponent } from './components/firstpage/firstpage.component';
import { SignupComponent } from './components/signup/signup.component';
import { MentorregComponent } from './components/mentorreg/mentorreg.component';
import { MenhomeComponent } from './components/menhome/menhome.component';
import { MenfirstComponent } from './components/menfirst/menfirst.component';
import { MennotifyComponent } from './components/mennotify/mennotify.component';
import { MenpayComponent } from './components/menpay/menpay.component';
import { UserhomeComponent } from './components/userhome/userhome.component';
import { UserpropComponent } from './components/userprop/userprop.component';
import { UserfirstComponent } from './components/userfirst/userfirst.component';
import { UsersearchComponent } from './components/usersearch/usersearch.component';
import { AdhomeComponent } from './components/adhome/adhome.component';
import { AdfirstComponent } from './components/adfirst/adfirst.component';
import { AdpaymadeComponent } from './components/adpaymade/adpaymade.component';
import { componentFactoryName } from '@angular/compiler';
import { AdpayComponent } from './components/adpay/adpay.component';
import { AdtechComponent } from './components/adtech/adtech.component';


const routes: Routes = [
  {
    path:'',redirectTo:'home',pathMatch:'full'
  },
  {
    path:'home',component:HomeComponent,
    children:[
      {
      path:'',redirectTo:'firstpage',pathMatch:'full'
    },
    {
      path:'firstpage',component:FirstpageComponent,
    },
    {
      path:'signup',component:SignupComponent
    },
      {
        path:'login',component:LoginComponent
      
      },
     
      {
        path:'mentorreg',component:MentorregComponent      }
    ]
    
  },
  {
    path:'',redirectTo:'menhome',pathMatch:'full'
  },
  {
  path:'menhome',component:MenhomeComponent,
  children:[
    {
    path:'',redirectTo:'menfirst',pathMatch:'full'
  },
  {
    path:'menfirst',component:MenfirstComponent
  },
  {
    path:'mennotify',component:MennotifyComponent
  },
  {
    path:'menpay',component:MenpayComponent
  }
]
  },
  {
    path:'',redirectTo:'userhome',pathMatch:'full'
  },
  {
  path:'userhome',component:UserhomeComponent,
  children:[
    {
    path:'',redirectTo:'userfirst',pathMatch:'full'
  },
  {
    path:'userfirst',component:UserfirstComponent
  },
  {
    path:'userprop',component:UserpropComponent
  },
  {
    path:'usersearch',component:UsersearchComponent
  }
]
},
{
  path:'',redirectTo:'adhome',pathMatch:'full'
},
{
path:'adhome',component:AdhomeComponent,
children:[
  {
  path:'',redirectTo:'adfirst',pathMatch:'full'
},
{
  path:'adfirst',component:AdfirstComponent
},
{
  path:'adpaymade',component:AdpaymadeComponent
},
{
path:'adpay',component:AdpayComponent
},
{
  path:'adtech',component:AdtechComponent
}
]
}
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
