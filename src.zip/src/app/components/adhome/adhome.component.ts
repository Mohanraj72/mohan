import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'adhome',
  templateUrl: './adhome.component.html',
  styleUrls: ['./adhome.component.css']
})
export class AdhomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
