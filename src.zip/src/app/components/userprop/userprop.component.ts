import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'userprop',
  templateUrl: './userprop.component.html',
  styleUrls: ['./userprop.component.css']
})
export class UserpropComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
