import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'usersearch',
  templateUrl: './usersearch.component.html',
  styleUrls: ['./usersearch.component.css']
})
export class UsersearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
