import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'menhome',
  templateUrl: './menhome.component.html',
  styleUrls: ['./menhome.component.css']
})
export class MenhomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
