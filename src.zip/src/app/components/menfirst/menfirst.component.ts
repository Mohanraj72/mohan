import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'menfirst',
  templateUrl: './menfirst.component.html',
  styleUrls: ['./menfirst.component.css']
})
export class MenfirstComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
