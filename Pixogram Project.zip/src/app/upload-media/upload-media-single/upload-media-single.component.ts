import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload-media-single',
  templateUrl: './upload-media-single.component.html',
  styleUrls: ['./upload-media-single.component.css']
})
export class UploadMediaSingleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
